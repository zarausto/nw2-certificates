<?php

/**
 * Fired during plugin activation
 *
 * @link       https://github.com/zarausto
 * @since      1.0.0
 *
 * @package    Nw2_Certificates
 * @subpackage Nw2_Certificates/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Nw2_Certificates
 * @subpackage Nw2_Certificates/includes
 * @author     Fausto Rodrigo Toloi <fausto@nw2web.com.br>
 */
class Nw2_Certificates_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
